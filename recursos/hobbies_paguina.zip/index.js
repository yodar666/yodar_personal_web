// codigo inspirado y modificado del canal de yt Tsoding 
//https://www.youtube.com/watch?v=qjWkNZ0SXfo&list=WL&index=10

const canvas = document.getElementById("game")
const ctx = canvas.getContext("2d")

const verde = "#39ff14"
const rosa = "#ff2bd6"
const relleno = "#07070a" 

const MAX_ASTEROIDES = 14
const reducirMovimiento = window.matchMedia("(prefers-reduced-motion: reduce)").matches

let W = 0
let H = 0

function resize() {
    const dpr = window.devicePixelRatio || 1
    W = window.innerWidth
    H = window.innerHeight
    canvas.width = W * dpr
    canvas.height = H * dpr
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
}

function rand(min, max) {
    return min + Math.random() * (max - min)
}

function crearAsteroide(inicial = false) {
    const r = rand(10, 36)
    const n = Math.floor(rand(8, 13))
    const vs = []
    for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2
        const rr = r * rand(0.7, 1.15)
        vs.push({ x: Math.cos(a) * rr, y: Math.sin(a) * rr })
    }
    const rapidez = rand(220, 520) * (1.3 - r / 60)
    return {
        vs,
        r,
        x: inicial ? rand(0, W + 200) : W + r + rand(0, 300),
        y: rand(-0.3 * H, 0.85 * H),
        vx: -rapidez,
        vy: rapidez * rand(0.12, 0.4),
        angulo: rand(0, Math.PI * 2),
        giro: rand(-2.5, 2.5),
        crater: { x: rand(-0.3, 0.3) * r, y: rand(-0.3, 0.3) * r, r: r * rand(0.15, 0.25) },
    }
}

function dibujarEstela(a) {
    const dur = 0.55
    const tx = a.x - a.vx * dur
    const ty = a.y - a.vy * dur
    const len = Math.hypot(a.vx, a.vy)
    const nx = -a.vy / len
    const ny = a.vx / len
    const ancho = a.r * 0.8

    const g = ctx.createLinearGradient(a.x, a.y, tx, ty)
    g.addColorStop(0, "rgba(255, 43, 214, 0.75)")
    g.addColorStop(1, "rgba(255, 43, 214, 0)")

    ctx.fillStyle = g
    ctx.beginPath()
    ctx.moveTo(a.x + nx * ancho, a.y + ny * ancho)
    ctx.lineTo(tx, ty)
    ctx.lineTo(a.x - nx * ancho, a.y - ny * ancho)
    ctx.closePath()
    ctx.fill()
    const g2 = ctx.createLinearGradient(a.x, a.y, tx, ty)
    g2.addColorStop(0, "rgba(57, 255, 20, 0.9)")
    g2.addColorStop(1, "rgba(57, 255, 20, 0)")
    ctx.strokeStyle = g2
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(a.x, a.y)
    ctx.lineTo(tx, ty)
    ctx.stroke()
}

function dibujarAsteroide(a) {
    const c = Math.cos(a.angulo)
    const s = Math.sin(a.angulo)
    ctx.beginPath()
    a.vs.forEach((v, i) => {
        const x = a.x + v.x * c - v.y * s
        const y = a.y + v.x * s + v.y * c
        if (i === 0) ctx.moveTo(x, y)
        else ctx.lineTo(x, y)
    })
    ctx.closePath()
    ctx.fillStyle = relleno
    ctx.fill()
    ctx.lineWidth = 2
    ctx.strokeStyle = verde
    ctx.shadowColor = verde
    ctx.shadowBlur = 10
    ctx.stroke()
    ctx.shadowBlur = 0
    const cx = a.x + a.crater.x * c - a.crater.y * s
    const cy = a.y + a.crater.x * s + a.crater.y * c
    ctx.lineWidth = 1.5
    ctx.strokeStyle = rosa
    ctx.beginPath()
    ctx.arc(cx, cy, a.crater.r, 0, Math.PI * 2)
    ctx.stroke()
}

let asteroides = []
let anterior = 0

function dibujar() {
    ctx.clearRect(0, 0, W, H)
    for (const a of asteroides) {
        dibujarEstela(a)
        dibujarAsteroide(a)
    }
}

function frame(t) {
    const dt = Math.min((t - anterior) / 1000, 0.05)
    anterior = t
    for (let i = 0; i < asteroides.length; i++) {
        const a = asteroides[i]
        a.x += a.vx * dt
        a.y += a.vy * dt
        a.angulo += a.giro * dt
        if (a.x < -a.r * 2 || a.y > H + a.r * 2) {
            asteroides[i] = crearAsteroide()
        }
    }

    dibujar()
    requestAnimationFrame(frame)
}

function iniciar() {
    resize()
    const cantidad = Math.min(MAX_ASTEROIDES, Math.max(6, Math.round(W / 90)))
    asteroides = Array.from({ length: cantidad }, () => crearAsteroide(true))
    if (reducirMovimiento) {
        dibujar()
    } else {
        requestAnimationFrame((t) => {
            anterior = t
            requestAnimationFrame(frame)
        })
    }
}

window.addEventListener("resize", () => {
    resize()
    if (reducirMovimiento) dibujar()
})

iniciar()